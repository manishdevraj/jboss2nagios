Installation
============

1. Copy the collector.sar (from the mbean/ directory) to your JBoss deploy directory. Port 5566 is then open for the plugin to access it.
2. Copy the plugin check_mbean_collector (from the plugin/ directory) to the Nagios plugin directory on the Nagios server.
3. Edit your Nagios config to use the check_mbean_collector to monitor any attributes of any MBean. 

Check the plugin's help for more options.

You might check, if the plugin and the MBean is working properly by doing a test run on the Nagios server:

./check_mbean_collector -H jbossserver -p 5566 -m jboss.system:type=ServerInfo -a ActiveThreadCount -w 200 -c 400

Please note that you need the nagios-plugins package installed and of course replace "jbossserver" above with you server name.

Configuration
=============

check_mbean_collector -H host[,host,..] -p port -m mbean-name -a attribute-name -w warning-level -c critical-level
check_mbean_collector [-h | --help]
check_mbean_collector [-V | --version]

  <host>           The server running JBoss.
                   Giving a comma separated list of hosts switches to a check for a singleton in a cluster.
  <port>           The port the deployed collector MBean is listening to
  <mbean_name>     The JMX name of the MBean that includes the attribute, e.g. jboss.system:type=ServerInfo
                   Use the ${some.env} notation to refer to a JVM environment variable on the server.
                   In Nagios config files this must be escaped like this: $$\\{some.env}
  <attribute_name> The name of the MBean attribute to retrieve, e.g. ActiveThreadCount
                   Prefix with * to get the difference between two calls (delta). ${...} can be used.
  <warning_level>  The level as a number from which on the WARNING status should be set
  <critical_level> The level as a number from which on the CRITICAL status should be set

If you are checking an attribute that is not a Number the specified text will raise the specific level if it can be found in the textual representation of the attribute.
If the attribute to check is a collection you can append [] to the attribute's name to compare to the size of the collection.

From version 0.9 of the collector mbean standard Nagios ranges are support with which you could check if an attribute leaves a specified range or if it falls below a given threshold.


Tips
====
 * How to integrate JBoss and JDK MBeans into one server to monitor all of them through jboss2nagios: http://www.jboss.org/community/docs/DOC-10521
 * Suggestions for attributes of mbeans you might want to monitor / graph: http://sourceforge.net/apps/trac/jboss2nagios/wiki/MBeanSuggestions
 * Add your configuration to the list of known working configurations: http://sourceforge.net/apps/trac/jboss2nagios/wiki/VersionMatrix


